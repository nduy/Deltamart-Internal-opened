Official link:Only accessible within DSI network
http://helpdesk-nuig.insight-centre.org/index.php/14-sample-data-articles/144-linux-vpn-configuration
