sudo docker-compose up
