import requests
import ast

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    x = requests.get('http://localhost/i/dcaquery.php?dcaID=1a8450621b');
 #   print(x.text);
    result = ast.literal_eval(x.text);
    print(result);
#    print_hi('PyCharm')








# See PyCharm help at https://www.jetbrains.com/help/pycharm/
