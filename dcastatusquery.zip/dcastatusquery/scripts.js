function generateMessage(p1) {
    alert(p1);
}